package Controllers;

import Domain.SubTipoMovimiento;
import Handlers.SubTipoMovimientoHandler;
import static Utils.JsonResponse.error;
import static Utils.JsonResponse.ok;
import com.fasterxml.jackson.databind.ObjectMapper;
import spark.Request;
import spark.Response;
import spark.Route;

public class SubTipoMovimientoController {
    public static Route getSubTipoMovimientos = (Request request, Response response) -> ok(SubTipoMovimientoHandler.getSubTipoMovimientos(), response);

    public static Route getSubTipoMovimiento = (Request request, Response response) -> {
        try {
            int id = Integer.parseInt(request.params(":id"));
            return ok(SubTipoMovimientoHandler.getSubTipoMovimiento(id), response);
        } catch (Exception e) {
            return error("El ID es invalido", response);
        }
    };

    public static Route deleteSubTipoMovimiento = (Request request, Response response) -> {
        try {
            int id = Integer.parseInt(request.params(":id"));
            return ok(SubTipoMovimientoHandler.deleteSubTipoMovimiento(id), response);
        } catch (Exception e) {
            return error("El ID es invalido", response);
        }
    };

    public static Route updateSubTipoMovimiento = (Request request, Response response) -> {
        String descripcion = request.queryParams("descripcion");

        if (descripcion != null) {
            try {
                int id = Integer.parseInt(request.params(":id"));
                return ok(SubTipoMovimientoHandler.updateSubTipoMovimiento(id, descripcion), response);
            } catch (Exception e) {
                return error("El ID es invalido", response);
            }
        } else {
            return error("No se recibio descripcion", response);
        }
    };

    public static Route addSubTipoMovimiento = (Request request, Response response) -> {
        ObjectMapper mapper = new ObjectMapper();
        SubTipoMovimiento aux = mapper.readValue(request.body(), SubTipoMovimiento.class);

        if (aux.getDescripcion() != null) {
            return ok(SubTipoMovimientoHandler.addSubTipoMovimiento(aux.getDescripcion()), response);
        } else {
            return error("No se recibio descripcion", response);
        }
    };
}


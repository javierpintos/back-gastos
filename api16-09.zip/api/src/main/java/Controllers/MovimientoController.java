package Controllers;

import java.util.ArrayList;
import java.util.Date;
import Domain.Movimiento;

public class MovimientoController {
    /*
    
    public ArrayList<Movimiento> _movimientos = new ArrayList<>();
    public ArrayList<DeudaXClienteProveedor> _DeudaXClienteProveedors = new ArrayList<>();
    
    public ControlMovimientos(ArrayList<Movimiento> movimientos){
        this._movimientos = movimientos;
    }
    
    //public ArrayList<Movimiento> verIngresos(Date fechaInicio, Date fechaFin){        
    public void verIngresos(Date fechaInicio, Date fechaFin){        
        ArrayList<Movimiento> aux = new ArrayList<>();
        for(Movimiento movimiento : _movimientos){
            if (movimiento.getFecha().compareTo(fechaInicio) > 0
                    && movimiento.getFecha().compareTo(fechaFin) < 0
                    && movimiento.getTipoMovimiento().getId() == 1) {
                aux.add(movimiento);
            }
        }
        if (aux.isEmpty()) {
             System.out.println("No hay movimientos entre esas fechas.");
        }else{
            for (Movimiento movimiento : aux) {
            System.out.println("Movimiento: " + aux);
        }
        }
        
        //return aux;
    }
    
    public ArrayList<Movimiento> verEgresos(Date fechaInicio, Date fechaFin){
        ArrayList<Movimiento> aux = new ArrayList<>();
        for(Movimiento movimiento : _movimientos){
            if (movimiento.getFecha().compareTo(fechaInicio) > 0
                    && movimiento.getFecha().compareTo(fechaFin) < 0
                    && movimiento.getTipoMovimiento().getId() == 2) {
                aux.add(movimiento);
            }
        }
        return aux;
    }
    
    public ArrayList<DeudaXClienteProveedor> dudaXAcreedor (Date fechaInicio, Date fechaFin){
        ArrayList<DeudaXClienteProveedor> aux = this.deudaXAcreedorMovimientos(fechaInicio,fechaFin);
        ArrayList<DeudaXClienteProveedor> deudaFinal = new ArrayList<>();
        for(int i = 0; i<aux.size(); i++){
            if(aux.get(i).getCliente() != null) {
                float monto = 0;
                for(int j = 0; j<aux.size(); j++){
                    if(aux.get(i).getCliente().getId() == aux.get(j).getCliente().getId() && i != j){
                        if(aux.get(j).getTipoMovimiento().getId() == 1 ){
                            monto = monto - aux.get(j).getDeuda();
                        } else {
                            monto = monto + aux.get(j).getDeuda();
                        }
                    }
                }
                DeudaXClienteProveedor _deudaParcial; 
                _deudaParcial = new DeudaXClienteProveedor(
                        aux.get(i).getCliente(),
                        null, null, monto);
                deudaFinal.add(_deudaParcial);//faltaba
            }
            if(aux.get(i).getProveedor() != null) {
                float monto = 0;
                for(int j = 0; j<aux.size(); j++){
                    if(aux.get(i).getProveedor().getId() == aux.get(j).getProveedor().getId() && i != j){
                        if(aux.get(j).getTipoMovimiento().getId() == 1 ){
                            monto = monto + aux.get(j).getDeuda();
                        } else {
                            monto = monto - aux.get(j).getDeuda();
                        }
                    }
                }
                DeudaXClienteProveedor _deudaParcial; 
                _deudaParcial = new DeudaXClienteProveedor(
                        null, aux.get(i).getProveedor(), null, monto);
                deudaFinal.add(_deudaParcial);//faltaba
            }
        }
        return deudaFinal;
    }
    
    public ArrayList<DeudaXClienteProveedor> deudaXAcreedorMovimientos(
            Date fechaInicio, Date fechaFin){
        ArrayList<DeudaXClienteProveedor> aux = new ArrayList<>();
        for(Movimiento movimiento : _movimientos){
            if (movimiento.getFecha().compareTo(fechaInicio) > 0
                    && movimiento.getFecha().compareTo(fechaFin) < 0) {
                if(movimiento.getCliente() != null){
                    DeudaXClienteProveedor _deudaCliente;
                    _deudaCliente = new DeudaXClienteProveedor(
                            movimiento.getCliente(),
                            null, 
                            movimiento.getTipoMovimiento(), 
                            movimiento.getMonto());
                    aux.add(_deudaCliente);
                }
                if(movimiento.getProveedor() != null){
                    DeudaXClienteProveedor _deudaCliente;
                    _deudaCliente = new DeudaXClienteProveedor(
                            null, 
                            movimiento.getProveedor(), 
                            movimiento.getTipoMovimiento(), 
                            movimiento.getMonto());
                    aux.add(_deudaCliente);
                }                
            }
        }
        return aux;
    }
    
    public float gastosXSubtipo(Date fechaInicio, Date fechaFin, int subTipo) {
        float monto = 0;
        for(Movimiento movimiento: _movimientos) {
            if(movimiento.getSubTipoMovimiento().getId() == subTipo 
                    && movimiento.getFecha().compareTo(fechaInicio) > 0
                    && movimiento.getFecha().compareTo(fechaFin) < 0
                    && movimiento.getTipoMovimiento().getId() == 2){
                monto = monto + movimiento.getMonto();
            }
        }
        return monto;
    }
    
    public float porcentajeAhorro(Date fechaInicio, Date fechaFin){
        float egresos = 0;
        float ingresos = 0;
        for(Movimiento movimiento: _movimientos){
            if(movimiento.getTipoMovimiento().getId() == 1) {
                ingresos = ingresos + movimiento.getMonto();
            } else {
                egresos = egresos + movimiento.getMonto();
            }
        }
        return egresos/ingresos;        
    }
    
    */
}

package Controllers;

import Domain.Moneda;
import com.fasterxml.jackson.databind.ObjectMapper;
import Handlers.MonedaHandler;
import spark.Request;
import spark.Response;
import spark.Route;
import static Utils.JsonResponse.error;
import static Utils.JsonResponse.ok;

public class MonedaController {
    public static Route getMonedas = (Request request, Response response) -> ok(MonedaHandler.getMonedas(), response);

    public static Route getMoneda = (Request request, Response response) -> {
        try {
            int id = Integer.parseInt(request.params(":id"));
            return ok(MonedaHandler.getMoneda(id), response);
        } catch (Exception e) {
            return error("El ID es invalido", response);
        }
    };

    public static Route deleteMoneda = (Request request, Response response) -> {
        try {
            int id = Integer.parseInt(request.params(":id"));
            return ok(MonedaHandler.deleteMoneda(id), response);
        } catch (Exception e) {
            return error("El ID es invalido", response);
        }
    };

    public static Route updateMoneda = (Request request, Response response) -> {
        String descripcion = request.queryParams("descripcion");

        if (descripcion != null) {
            try {
                int id = Integer.parseInt(request.params(":id"));
                return ok(MonedaHandler.updateMoneda(id, descripcion), response);
            } catch (Exception e) {
                return error("El ID es invalido", response);
            }
        } else {
            return error("No se recibio descripcion", response);
        }
    };

    public static Route addMoneda = (Request request, Response response) -> {
        ObjectMapper mapper = new ObjectMapper();
        Moneda aux = mapper.readValue(request.body(), Moneda.class);

        if (aux.getDescripcion() != null) {
            return ok(MonedaHandler.addMoneda(aux.getDescripcion(), aux.getCotizacion()), response);
        } else {
            return error("No se recibio descripcion", response);
        }
    };
}

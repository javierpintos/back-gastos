package Controllers;

import Domain.TipoPago;
import Handlers.TipoPagoHandler;
import static Utils.JsonResponse.error;
import static Utils.JsonResponse.ok;
import com.fasterxml.jackson.databind.ObjectMapper;
import spark.Request;
import spark.Response;
import spark.Route;

public class TipoPagoController {
    public static Route getTipoPagos = (Request request, Response response) -> ok(TipoPagoHandler.getTipoPagos(), response);

    public static Route getTipoPago = (Request request, Response response) -> {
        try {
            int id = Integer.parseInt(request.params(":id"));
            return ok(TipoPagoHandler.getTipoPago(id), response);
        } catch (Exception e) {
            return error("El ID es invalido", response);
        }
    };

    public static Route deleteTipoPago = (Request request, Response response) -> {
        try {
            int id = Integer.parseInt(request.params(":id"));
            return ok(TipoPagoHandler.deleteTipoPago(id), response);
        } catch (Exception e) {
            return error("El ID es invalido", response);
        }
    };

    public static Route updateTipoPago = (Request request, Response response) -> {
        String descripcion = request.queryParams("descripcion");

        if (descripcion != null) {
            try {
                int id = Integer.parseInt(request.params(":id"));
                return ok(TipoPagoHandler.updateTipoPago(id, descripcion), response);
            } catch (Exception e) {
                return error("El ID es invalido", response);
            }
        } else {
            return error("No se recibio descripcion", response);
        }
    };

    public static Route addTipoPago = (Request request, Response response) -> {
        ObjectMapper mapper = new ObjectMapper();
        TipoPago aux = mapper.readValue(request.body(), TipoPago.class);

        if (aux.getDescripcion() != null) {
            return ok(TipoPagoHandler.addTipoPago(aux.getDescripcion()), response);
        } else {
            return error("No se recibio descripcion", response);
        }
    };
}

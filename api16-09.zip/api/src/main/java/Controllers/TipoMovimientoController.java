package Controllers;

import Domain.TipoMovimiento;
import Handlers.TipoMovimientoHandler;
import static Utils.JsonResponse.error;
import static Utils.JsonResponse.ok;
import com.fasterxml.jackson.databind.ObjectMapper;
import spark.Request;
import spark.Response;
import spark.Route;

public class TipoMovimientoController {
    public static Route getTipoMovimientos = (Request request, Response response) -> ok(TipoMovimientoHandler.getTipoMovimientos(), response);

    public static Route getTipoMovimiento = (Request request, Response response) -> {
        try {
            int id = Integer.parseInt(request.params(":id"));
            return ok(TipoMovimientoHandler.getTipoMovimiento(id), response);
        } catch (Exception e) {
            return error("El ID es invalido", response);
        }
    };

    public static Route deleteTipoMovimiento = (Request request, Response response) -> {
        try {
            int id = Integer.parseInt(request.params(":id"));
            return ok(TipoMovimientoHandler.deleteTipoMovimiento(id), response);
        } catch (Exception e) {
            return error("El ID es invalido", response);
        }
    };

    public static Route updateTipoMovimiento = (Request request, Response response) -> {
        String descripcion = request.queryParams("descripcion");

        if (descripcion != null) {
            try {
                int id = Integer.parseInt(request.params(":id"));
                return ok(TipoMovimientoHandler.updateTipoMovimiento(id, descripcion), response);
            } catch (Exception e) {
                return error("El ID es invalido", response);
            }
        } else {
            return error("No se recibio descripcion", response);
        }
    };

    public static Route addTipoMovimiento = (Request request, Response response) -> {
        ObjectMapper mapper = new ObjectMapper();
        TipoMovimiento aux = mapper.readValue(request.body(), TipoMovimiento.class);

        if (aux.getDescripcion() != null) {
            return ok(TipoMovimientoHandler.addTipoMovimiento(aux.getDescripcion()), response);
        } else {
            return error("No se recibio descripcion", response);
        }
    };
}

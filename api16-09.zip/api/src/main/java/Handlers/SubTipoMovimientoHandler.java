package Handlers;

import Domain.SubTipoMovimiento;
import java.util.ArrayList;

public class SubTipoMovimientoHandler {
    private static ArrayList<SubTipoMovimiento> _subTipoMovimientos = new ArrayList<SubTipoMovimiento>();

    public SubTipoMovimientoHandler() {
    }

    public SubTipoMovimientoHandler(ArrayList<SubTipoMovimiento> _subTipoMovimientos) {
        this._subTipoMovimientos = _subTipoMovimientos;
    }

    public static ArrayList<SubTipoMovimiento> getSubTipoMovimientos() {
        return _subTipoMovimientos;
    }

    public static SubTipoMovimiento getSubTipoMovimiento(int id) {
        for (SubTipoMovimiento subTipoMovimientos:_subTipoMovimientos) {
            if ( subTipoMovimientos.getId() == id ) {
                return subTipoMovimientos;
            }
        }
        return null;
    }

    public static SubTipoMovimiento deleteSubTipoMovimiento(int id) {
        int index = 0;
        for (SubTipoMovimiento subTipoMovimientos:_subTipoMovimientos) {
            if ( subTipoMovimientos.getId() == id ) {
                return _subTipoMovimientos.remove(index);
            }
            index++;
        }
        return null;
    }

    public static SubTipoMovimiento updateSubTipoMovimiento(int id, String descripcion) {
        int index = 0;
        int indexUpdate = -1;
        SubTipoMovimiento aux;

        for (SubTipoMovimiento subTipoMovimientos:_subTipoMovimientos) {
            if ( subTipoMovimientos.getDescripcion().toLowerCase().equals(descripcion.toLowerCase()) ) {
                return null;
            }

            if ( subTipoMovimientos.getId() == id ) {
                indexUpdate = index;
            }
            index++;
        }

        if (indexUpdate != -1) {
            aux = _subTipoMovimientos.get(indexUpdate);
            aux.setDescripcion(descripcion);
            _subTipoMovimientos.set(indexUpdate, aux);
            return aux;
        }

        return null;
    }

    public static SubTipoMovimiento addSubTipoMovimiento(String descripcion) {
        for (SubTipoMovimiento subTipoMovimientos:_subTipoMovimientos) {
            if ( subTipoMovimientos.getDescripcion().toLowerCase().equals(descripcion.toLowerCase()) ) {
                return subTipoMovimientos;
            }
        }
        SubTipoMovimiento nuevo = new SubTipoMovimiento(_subTipoMovimientos.size() + 1, descripcion);
        _subTipoMovimientos.add(nuevo);

        return nuevo;
    }

    @Override
    public String toString() {
        return "SubTipoMovimientoHandler{" +
                "subTipoMovimientos=" + _subTipoMovimientos +
                '}';
    }
}


package Handlers;

import Domain.TipoPago;
import java.util.ArrayList;

public class TipoPagoHandler {
    private static ArrayList<TipoPago> _tipoPagos = new ArrayList<TipoPago>();

    public TipoPagoHandler() {
    }

    public TipoPagoHandler(ArrayList<TipoPago> _tipoPagos) {
        this._tipoPagos = _tipoPagos;
    }

    public static ArrayList<TipoPago> getTipoPagos() {
        return _tipoPagos;
    }

    public static TipoPago getTipoPago(int id) {
        for (TipoPago tipoPagos:_tipoPagos) {
            if ( tipoPagos.getId() == id ) {
                return tipoPagos;
            }
        }
        return null;
    }

    public static TipoPago deleteTipoPago(int id) {
        int index = 0;
        for (TipoPago tipoPagos:_tipoPagos) {
            if ( tipoPagos.getId() == id ) {
                return _tipoPagos.remove(index);
            }
            index++;
        }
        return null;
    }

    public static TipoPago updateTipoPago(int id, String descripcion) {
        int index = 0;
        int indexUpdate = -1;
        TipoPago aux;

        for (TipoPago tipoPagos:_tipoPagos) {
            if ( tipoPagos.getDescripcion().toLowerCase().equals(descripcion.toLowerCase()) ) {
                return null;
            }

            if ( tipoPagos.getId() == id ) {
                indexUpdate = index;
            }
            index++;
        }

        if (indexUpdate != -1) {
            aux = _tipoPagos.get(indexUpdate);
            aux.setDescripcion(descripcion);
            _tipoPagos.set(indexUpdate, aux);
            return aux;
        }

        return null;
    }

    public static TipoPago addTipoPago(String descripcion) {
        for (TipoPago tipoPagos:_tipoPagos) {
            if ( tipoPagos.getDescripcion().toLowerCase().equals(descripcion.toLowerCase()) ) {
                return tipoPagos;
            }
        }
        TipoPago nuevo = new TipoPago(_tipoPagos.size() + 1, descripcion);
        _tipoPagos.add(nuevo);

        return nuevo;
    }

    @Override
    public String toString() {
        return "TipoPagoHandler{" +
                "tipoPagos=" + _tipoPagos +
                '}';
    }
}


package Handlers;

import Domain.TipoMovimiento;
import java.util.ArrayList;

public class TipoMovimientoHandler {
    private static ArrayList<TipoMovimiento> _tipoMovimientos = new ArrayList<TipoMovimiento>();

    public TipoMovimientoHandler() {
    }

    public TipoMovimientoHandler(ArrayList<TipoMovimiento> _tipoMovimientos) {
        this._tipoMovimientos = _tipoMovimientos;
    }

    public static ArrayList<TipoMovimiento> getTipoMovimientos() {
        return _tipoMovimientos;
    }

    public static TipoMovimiento getTipoMovimiento(int id) {
        for (TipoMovimiento tipoMovimientos:_tipoMovimientos) {
            if ( tipoMovimientos.getId() == id ) {
                return tipoMovimientos;
            }
        }
        return null;
    }

    public static TipoMovimiento deleteTipoMovimiento(int id) {
        int index = 0;
        for (TipoMovimiento tipoMovimientos:_tipoMovimientos) {
            if ( tipoMovimientos.getId() == id ) {
                return _tipoMovimientos.remove(index);
            }
            index++;
        }
        return null;
    }

    public static TipoMovimiento updateTipoMovimiento(int id, String descripcion) {
        int index = 0;
        int indexUpdate = -1;
        TipoMovimiento aux;

        for (TipoMovimiento tipoMovimientos:_tipoMovimientos) {
            if ( tipoMovimientos.getDescripcion().toLowerCase().equals(descripcion.toLowerCase()) ) {
                return null;
            }

            if ( tipoMovimientos.getId() == id ) {
                indexUpdate = index;
            }
            index++;
        }

        if (indexUpdate != -1) {
            aux = _tipoMovimientos.get(indexUpdate);
            aux.setDescripcion(descripcion);
            _tipoMovimientos.set(indexUpdate, aux);
            return aux;
        }

        return null;
    }

    public static TipoMovimiento addTipoMovimiento(String descripcion) {
        for (TipoMovimiento tipoMovimientos:_tipoMovimientos) {
            if ( tipoMovimientos.getDescripcion().toLowerCase().equals(descripcion.toLowerCase()) ) {
                return tipoMovimientos;
            }
        }
        TipoMovimiento nuevo = new TipoMovimiento(_tipoMovimientos.size() + 1, descripcion);
        _tipoMovimientos.add(nuevo);

        return nuevo;
    }

    @Override
    public String toString() {
        return "TipoMovimientoHandler{" +
                "tipoMovimientos=" + _tipoMovimientos +
                '}';
    }
}


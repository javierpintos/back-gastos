package Domain;

public class Proveedor extends Persona{
    private String cuit;
    private String contacto;
    private String telefonoContacto;
    
    public Proveedor(){}

    public Proveedor(String cuit, String contacto, String telefonoContacto,
            int id, String nombre, String apellido, String dni) {
        super(id, nombre, apellido, dni);
        this.cuit = cuit;
        this.contacto = contacto;
        this.telefonoContacto = telefonoContacto;
    }

    public String getCuit() {
        return cuit;
    }

    public void setCuit(String cuit) {
        this.cuit = cuit;
    }

    public String getContacto() {
        return contacto;
    }

    public void setContacto(String contacto) {
        this.contacto = contacto;
    }

    public String getTelefonoContacto() {
        return telefonoContacto;
    }

    public void setTelefonoContacto(String telefonoContacto) {
        this.telefonoContacto = telefonoContacto;
    }

    @Override
    public String toString() {
        return "Proveedor{" + " cuit=" + cuit + ", contacto=" + contacto + 
                ", telefonoContacto=" + telefonoContacto + super.toString() + '}';
    }

}

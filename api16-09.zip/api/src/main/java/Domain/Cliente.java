package Domain;

public class Cliente extends Persona{
    private String codigoCliente;

    public Cliente() {
    }

    public Cliente(int id, String nombre, String apellido, String dni, String codigoCliente) {
        super(id, nombre, apellido, dni);
        this.codigoCliente = codigoCliente;
    }
    
    public String getCodigoCliente() {
        return codigoCliente;
    }

    public void setCodigoCliente(String codigoCliente) {
        this.codigoCliente = codigoCliente;
    }
    
    @Override
    public String toString() {
        return  "Cliente{" + "codigoCliente=" + codigoCliente + super.toString();
    }
}

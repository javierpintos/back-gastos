package Domain;

public class TipoMovimiento {
    
    private static int INGRESO=1;
    private static int EGRESO=2;
    
    private int id;
    private String descripcion;

    public TipoMovimiento(int id, String descripcion) {
        this.id = id;
        this.descripcion = descripcion;
    }
    
    public TipoMovimiento(){
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    /*public static int getINGRESO() {
        return INGRESO;
    }

    public static void setINGRESO(int INGRESO) {
        TipoMovimiento.INGRESO = INGRESO;
    }

    public static int getEGRESO() {
        return EGRESO;
    }

    public static void setEGRESO(int EGRESO) {
        TipoMovimiento.EGRESO = EGRESO;
    }*/

    @Override
    public String toString() {
        return "TipoMovimiento{" + "id=" + id + ", descripcion=" + descripcion + '}';
    }
}
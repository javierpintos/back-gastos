package Domain;

import java.util.Date;

public class Movimiento {
    //cuando hice el movimiento
    private Date fecha;
    //cuando se vence la deuda si pague con credito por ej.
    private Date fechaVencimiento;
    //cuanto es el movimiento
    private float monto;
    // algun dato que me ayude a entender el movimiento
    private String descripcion;
    //  identificar que tipo de movimiento (ingreso - egreso)
    private TipoMovimiento TipoMovimiento;
    // identificar que tipo de submovimientos
    // ejemplo: carniceria - verduleria
    // me ayuda para futuros controles o filtrados
    private SubTipoMovimiento subTipoMovimiento;
    // historial de cotizacion de la moneda
    private float cotizacion;
    // tipo de moneda: dolar, peso, etc.
    private Moneda moneda;
    // tipo de pago: efectivo, credito, debito, ETC.
    private TipoPago tipoPago;
    
    private Cliente cliente;    
    private Proveedor proveedor;

    public Movimiento() {
    }

    public Movimiento(Date fecha, Date fechaVencimiento, float monto, String descripcion, TipoMovimiento TipoMovimiento, SubTipoMovimiento subTipoMovimiento, float cotizacion, Moneda moneda, Cliente cliente, Proveedor proveedor) {
        this.fecha = fecha;
        this.fechaVencimiento = fechaVencimiento;
        this.monto = monto;
        this.descripcion = descripcion;
        this.TipoMovimiento = TipoMovimiento;
        this.subTipoMovimiento = subTipoMovimiento;
        this.cotizacion = cotizacion;
        this.moneda = moneda;
        this.cliente = cliente;
        this.proveedor = proveedor;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Date getFechaVencimiento() {
        return fechaVencimiento;
    }

    public void setFechaVencimiento(Date fechaVencimiento) {
        this.fechaVencimiento = fechaVencimiento;
    }

    public float getMonto() {
        return monto;
    }

    public void setMonto(float monto) {
        this.monto = monto;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public TipoMovimiento getTipoMovimiento() {
        return TipoMovimiento;
    }

    public void setTipoMovimiento(TipoMovimiento TipoMovimiento) {
        this.TipoMovimiento = TipoMovimiento;
    }

    public SubTipoMovimiento getSubTipoMovimiento() {
        return subTipoMovimiento;
    }

    public void setSubTipoMovimiento(SubTipoMovimiento subTipoMovimiento) {
        this.subTipoMovimiento = subTipoMovimiento;
    }

    public float getCotizacion() {
        return cotizacion;
    }

    public void setCotizacion(float cotizacion) {
        this.cotizacion = cotizacion;
    }

    public Moneda getMoneda() {
        return moneda;
    }

    public void setMoneda(Moneda moneda) {
        this.moneda = moneda;
    }

    public TipoPago getTipoPago() {
        return tipoPago;
    }

    public void setTipoPago(TipoPago tipoPago) {
        this.tipoPago = tipoPago;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Proveedor getProveedor() {
        return proveedor;
    }

    public void setProveedor(Proveedor proveedor) {
        this.proveedor = proveedor;
    }

    @Override
    public String toString() {
        return "Movimiento{" + "fecha=" + fecha + ", fechaVencimiento=" + fechaVencimiento + ", monto=" + monto + ", descripcion=" + descripcion + ", TipoMovimiento=" + TipoMovimiento + ", subTipoMovimiento=" + subTipoMovimiento + ", cotizacion=" + cotizacion + ", moneda=" + moneda + ", tipoPago=" + tipoPago + ", cliente=" + cliente + ", proveedor=" + proveedor + '}';
    }
    
    
}
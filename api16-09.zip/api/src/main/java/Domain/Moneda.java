package Domain;

public class Moneda {
    public int id;
    public String descripcion;
    public String cotizacion;

    public Moneda() {
    }

    public Moneda(int id, String descripcion, String cotizacion) {
        this.id = id;
        this.descripcion = descripcion;
        this.cotizacion = cotizacion;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getCotizacion() {
        return cotizacion;
    }

    public void setCotizacion(String cotizacion) {
        this.cotizacion = cotizacion;
    }

    @Override
    public String toString() {
        return "Moneda{" +
                "id=" + id +
                ", descripcion='" + descripcion + '\'' +
                ", cotizacion='" + cotizacion + '\'' +
                '}';
    }
}

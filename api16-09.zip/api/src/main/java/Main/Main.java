package Main;

import static spark.Spark.*;
import spark.Filter;
import Controllers.MonedaController;
import Controllers.TipoPagoController;
import Controllers.SubTipoMovimientoController;
import Controllers.TipoMovimientoController;

public class Main {

    public static void main(String[] args) {

        // Puerto
        port(8080);
        
        options("/*", (request, response) -> {
            String accessControlRequestHeaders = request.headers("Access-Control-Request-Headers");
            if (accessControlRequestHeaders != null) {
                response.header("Access-Control-Allow-Headers", accessControlRequestHeaders);
            }

            String accessControlRequestMethod = request.headers("Access-Control-Request-Method");
            if (accessControlRequestMethod != null) {
                response.header("Access-Control-Allow-Methods", accessControlRequestMethod);
            }
            return "OK";
        });
        
        before((request, response) -> response.header("Access-Control-Allow-Origin", "*"));
        
        /*after((Filter) (request, response) -> {
            response.header("Access-Control-Allow-Origin", "*");
            response.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
            response.header("Access-Control-Allow-Headers", "Content-Type, application/json, api_key, Authorization");
        });*/

        // Rutas
        path("/api", () -> {
            // Listar monedas
            // GET: http://localhost:8080/api/monedas
            get("/monedas", MonedaController.getMonedas);

            // Mostrar una moneda por ID
            // GET: http://localhost:8080/api/monedas/1
            get("/monedas/:id", MonedaController.getMoneda);

            // Eliminar moneda por ID
            // DELETE: http://localhost:8080/api/monedas/1
            delete("/monedas/:id", MonedaController.deleteMoneda);

            // Actualizar moneda por ID
            // PUT: http://localhost:8080/api/monedas/1
            // RECIBE: "descripcion" (ARS, USD, EUR, etc)
            put("/monedas/:id", MonedaController.updateMoneda);

            // Agregar moneda
            // POST: http://localhost:8080/api/monedas
            // RECIBE: "descripcion" (ARS, USD, EUR, etc)
            // RECIBE: "cotizacion" (por ej. 70)
            post("/monedas", MonedaController.addMoneda);
            
            
            
            // Listar tipoPagos
            // GET: http://localhost:8080/api/tipoPagos
            get("/tipoPagos", TipoPagoController.getTipoPagos);

            // Mostrar una tipoPago por ID
            // GET: http://localhost:8080/api/tipoPagos/1
            get("/tipoPagos/:id", TipoPagoController.getTipoPago);

            // Eliminar tipoPago por ID
            // DELETE: http://localhost:8080/api/tipoPagos/1
            delete("/tipoPagos/:id", TipoPagoController.deleteTipoPago);

            // Actualizar tipoPago por ID
            // PUT: http://localhost:8080/api/tipoPagos/1
            // RECIBE: "descripcion" (efectivo, credito, debito, etc)
            put("/tipoPagos/:id", TipoPagoController.updateTipoPago);

            // Agregar tipoPago
            // POST: http://localhost:8080/api/tipoPagos
            // RECIBE: "descripcion" (efectivo, credito, debito, etc)
            post("/tipoPagos", TipoPagoController.addTipoPago);
            
            
            
            // Listar tipoMovimientos
            // GET: http://localhost:8080/api/tipoMovimientos
            get("/tipoMovimientos", TipoMovimientoController.getTipoMovimientos);

            // Mostrar una tipoMovimiento por ID
            // GET: http://localhost:8080/api/tipoMovimientos/1
            get("/tipoMovimientos/:id", TipoMovimientoController.getTipoMovimiento);

            // Eliminar tipoMovimiento por ID
            // DELETE: http://localhost:8080/api/tipoMovimientos/1
            delete("/tipoMovimientos/:id", TipoMovimientoController.deleteTipoMovimiento);

            // Actualizar tipoMovimiento por ID
            // PUT: http://localhost:8080/api/tipoMovimientos/1
            // RECIBE: "descripcion" (ingreso, egreso, etc)
            put("/tipoMovimientos/:id", TipoMovimientoController.updateTipoMovimiento);

            // Agregar tipoMovimiento
            // POST: http://localhost:8080/api/tipoMovimientos
            // RECIBE: "descripcion" (ingreso, egreso, etc)
            post("/tipoMovimientos", TipoMovimientoController.addTipoMovimiento);
            
            
            
            // Listar subTipoMovimientos
            // GET: http://localhost:8080/api/subSubTipoMovimientos
            get("/subTipoMovimientos", SubTipoMovimientoController.getSubTipoMovimientos);

            // Mostrar una tipoMovimiento por ID
            // GET: http://localhost:8080/api/subSubTipoMovimientos/1
            get("/subTipoMovimientos/:id", SubTipoMovimientoController.getSubTipoMovimiento);

            // Eliminar tipoMovimiento por ID
            // DELETE: http://localhost:8080/api/subSubTipoMovimientos/1
            delete("/subTipoMovimientos/:id", SubTipoMovimientoController.deleteSubTipoMovimiento);

            // Actualizar tipoMovimiento por ID
            // PUT: http://localhost:8080/api/subSubTipoMovimientos/1
            // RECIBE: "descripcion" (ingreso, egreso, etc)
            put("/subTipoMovimientos/:id", SubTipoMovimientoController.updateSubTipoMovimiento);

            // Agregar tipoMovimiento
            // POST: http://localhost:8080/api/subSubTipoMovimientos
            // RECIBE: "descripcion" (ingreso, egreso, etc)
            post("/subTipoMovimientos", SubTipoMovimientoController.addSubTipoMovimiento);
            
            
            get("/*", (Request, Response) -> "Ingrese una URL valida");
        });

    }
}